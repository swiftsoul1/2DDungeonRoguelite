using System.Collections;
using System.Collections.Generic;
using UnityEngine;

interface ILivingState
{
    public void attack(LivingObject target);
    public void takeDamage(int damage);
}

