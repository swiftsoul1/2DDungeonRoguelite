using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DeadState : ILivingState
{

    LivingEntity host;

    public DeadState(LivingEntity host)
    {
        this.host = host;
    }

    public void attack(LivingEntity enemy)
    {
        return;
    }

    public void takeDamage(int dmg)
    {
        return;
    }

}
