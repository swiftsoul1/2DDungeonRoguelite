using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AliveState : ILivingState
{

    LivingEntity host;

    public AliveState(LivingEntity host)
    {
        this.host = host;
    }


    public override void attack(LivingEntity target)
    {
        target.takeDamage();
    }

    public override void takeDamage(int damage)
    {
        if (damage < 0)
        {
            damage = 0;
        }

        host.CurrentHealth -= damage

        if (host.CurrentHealth < 0)
        {
            //this state = dead state
        }
    }

}
